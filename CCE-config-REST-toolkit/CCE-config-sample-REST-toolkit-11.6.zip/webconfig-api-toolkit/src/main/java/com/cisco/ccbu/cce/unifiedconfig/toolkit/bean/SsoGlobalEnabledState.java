// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum SsoGlobalEnabledState {
  NON_SSO,
  SSO,
  HYBRID
}
