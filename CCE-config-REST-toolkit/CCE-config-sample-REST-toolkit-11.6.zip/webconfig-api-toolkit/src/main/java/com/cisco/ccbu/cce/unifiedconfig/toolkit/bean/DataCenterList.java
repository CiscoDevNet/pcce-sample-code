// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@Path("datacenter")
@XmlRootElement(name="results")
public class DataCenterList extends BaseApiBean {
  private List<DataCenter> items;
  private PageInfo pageInfo;
  private PermissionInfo permissionInfo;

  @XmlElementWrapper(name="datacenters")
  @XmlElement(name="datacenter")
  public List<DataCenter> getItems() {
     return this.items;
  }

  public void setItems(List<DataCenter> items) {
     this.items = items;
  }

  public PageInfo getPageInfo() {
     return this.pageInfo;
  }

  public void setPageInfo(PageInfo pageInfo) {
     this.pageInfo = pageInfo;
  }

  public PermissionInfo getPermissionInfo() {
     return this.permissionInfo;
  }

  public void setPermissionInfo(PermissionInfo permissionInfo) {
     this.permissionInfo = permissionInfo;
  }


  @Path("datacenter")
  @XmlRootElement(name = "results")
  public static class DataCenterListList extends BaseApiListBean<DataCenterList> {
    @XmlElementWrapper(name = "resultss")
    @XmlElement(name = "results")
    public List<DataCenterList> getItems() {
      return items;
    }

    public void setItems(List<DataCenterList> items) {
      this.items = items;
    }
  }
}
