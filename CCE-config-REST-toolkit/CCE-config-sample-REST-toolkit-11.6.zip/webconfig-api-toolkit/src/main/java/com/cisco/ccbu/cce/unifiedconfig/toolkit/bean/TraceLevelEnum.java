// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum TraceLevelEnum {
  NORMAL,
  DETAILED,
  CUSTOM,
  INITIALIZING,
  INVALID
}
