package com.cisco.ccbu.cce.unifiedconfig.toolkit.examples;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.*;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.bean.*;

import javax.ws.rs.Path;
import java.io.IOException;
import java.util.*;

/**
 * Sample code for how to create/update/delete a remote site.  See the accompanying file site.properties for
 * values that need to be provided.
 *
 * Command line launch: mvn exec:java -Dexec.mainClass="com.cisco.ccbu.cce.unifiedconfig.toolkit.examples.RemoteSiteDemo"
 */
public class RemoteSiteDemo {

    private static final String REMOTE_SITE_SIDE_A_PG_ADDRESS = "remotesite.side.a.address";
    private static final String REMOTE_SITE_SIDE_B_PG_ADDRESS = "remotesite.side.b.address";

    private static final String REMOTE_SITE_SIDE_A_CM_SUB_ADDRESS = "remotesite.cm.sub.side.a.name";
    private static final String REMOTE_SITE_SIDE_B_CM_SUB_ADDRESS = "remotesite.cm.sub.side.b.name";

    private static final String REMOTE_SITE_FINESSE_PUB_HOSTNAME = "remotesite.finesse.pub.hostname";
    private static final String REMOTE_SITE_FINESSE_DIAG_USERNAME = "remotesite.finesse.diag.username";
    private static final String REMOTE_SITE_FINESSE_DIAG_PASSWORD = "remotesite.finesse.diag.password";

    private static final String REMOTE_SITE_SETTINGS_CODEC = "remotesite.settings.codec";

    private static final String REMOTE_SITE_SIDE_A_CVP_ADDRESS = "remotesite.cvp.side.a.host";
    private static final String REMOTE_SITE_SIDE_B_CVP_ADDRESS = "remotesite.cvp.side.b.host";

    private static final String REMOTE_SITE_NAME = "remotesite.name";

    private static final String YES = "y";
    private static final String NO = "n";

    private RESTClient restClient;
    private Properties props;
    private DataCenter demoSite;

    private static Map<MachineType, List<MachineHost>> typeToMachineMap;

    public RemoteSiteDemo(Properties props) {
        this.props = props;

        // Create a new RESTClient object with the IP of your AW HDS
        restClient = new RESTClient(props.getProperty(DemoUtils.PCCE_HOST), props.getProperty(DemoUtils.CCE_DIAG_USERNAME), props.getProperty(DemoUtils.CCE_DIAG_PASSWORD));

        Deployment deploymentType = restClient.get(Deployment.class, RESTClient.baseUrl + Deployment.class.getAnnotation(Path.class).value());

        System.out.println("System is in Deployment Type: " + deploymentType.getDeploymentType());

        if (deploymentType.getDeploymentType() != 7 && deploymentType.getDeploymentType() != 10) {
            System.out.println("RemoteSiteDemo can only be run in PCCE (7) or PCCE_LAB (10) deployments.");
            System.exit(0);
        }

        //load all the machines in the PCCE inventory and keep a machine type to machine map
        typeToMachineMap = DemoUtils.loadMachines(restClient);
    }

    /**
     * The main method.
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        Properties props = new Properties();
        props.load(InitializeDemo.class.getResourceAsStream("/site.properties"));

        RemoteSiteDemo remoteSiteDemo = new RemoteSiteDemo(props);

        //Create a remote site with agent and multichannel PG
        remoteSiteDemo.createRemoteSite();
        //Update the remote site with VRU PG
        remoteSiteDemo.updateRemoteSite();
        //Delete the remote site
        if(confirmDelete()) {
            remoteSiteDemo.deleteRemoteSite();
        }
    }

    /**
     * Confirm whether the site is to be deleted or not
     *
     * @return true if the user enters 'y'
     *         false if the user enters 'n',
     *         ask for delete confirmation again if the user enters any other input
     */
    private static boolean confirmDelete() {
        System.out.println("Do you want to delete the remote site? (Answer y/n)");
        Scanner sc = new Scanner(System.in);
        String input = sc.next();
        if(input.equals(YES)) {
            return true;
        } else if(input.equals(NO)) {
            return false;
        } else {
            confirmDelete();
        }
        return false;
    }

    /**
     * Create the remote site with agent PG and multichannel PG
     */
    private void createRemoteSite() {
        System.out.println("Creating remote site with agent and multichannel PG...This may take up to 20 minutes");
        DataCenter bean = new DataCenter();
        bean.setName(props.getProperty(REMOTE_SITE_NAME));

        //set SideA and SideB PG
        bean.setSideAPGAddress(props.getProperty(REMOTE_SITE_SIDE_A_PG_ADDRESS));
        bean.setSideBPGAddress(props.getProperty(REMOTE_SITE_SIDE_B_PG_ADDRESS));

        //Set Multichannel PG fields
        MultiChannelPG multiChannelPG = new MultiChannelPG();
        multiChannelPG.setConfigured(true);
        bean.setMultiChannelPG(multiChannelPG);

        /*******Agent PG configuration - start**********/
        //Set Agent PG fields
        AgentPG agentPG = new AgentPG();
        agentPG.setConfigured(true);
        //Set side A CM subscriber data
        MachineHost cmSubSideA = DemoUtils.findMachineByName(typeToMachineMap, MachineType.EXTERNAL_CM_SUBSCRIBER, props.getProperty(REMOTE_SITE_SIDE_A_CM_SUB_ADDRESS));
        ReferenceBean cmSubSideARef = new ReferenceBean();
        cmSubSideARef.setName(cmSubSideA.getName());
        cmSubSideARef.setRefURL(cmSubSideA.getRefURL());
        //Set side B CM subscriber data
        MachineHost cmSubSideB = DemoUtils.findMachineByName(typeToMachineMap, MachineType.EXTERNAL_CM_SUBSCRIBER, props.getProperty(REMOTE_SITE_SIDE_B_CM_SUB_ADDRESS));
        ReferenceBean cmSubSideBRef = new ReferenceBean();
        cmSubSideBRef.setName(cmSubSideB.getName());
        cmSubSideBRef.setRefURL(cmSubSideB.getRefURL());

        agentPG.setCmSubSideA(cmSubSideARef);
        agentPG.setCmSubSideB(cmSubSideBRef);

        //Set Finesse data
        agentPG.setFinessePrimaryAddress(props.getProperty(REMOTE_SITE_FINESSE_PUB_HOSTNAME));
        agentPG.setFinesseUserName(props.getProperty(REMOTE_SITE_FINESSE_DIAG_USERNAME));
        agentPG.setFinessePassword(props.getProperty(REMOTE_SITE_FINESSE_DIAG_PASSWORD));

        //Set mobile agent codec
        agentPG.setMobileAgentCodec(props.getProperty(REMOTE_SITE_SETTINGS_CODEC));

        bean.setAgentPG(agentPG);
        /*******Agent PG configuration - end**********/

        demoSite = restClient.createAndGetBean(bean);
        System.out.println("Created remote site "+demoSite.getName()+" successfully.");
    }

    /**
     * Update the remote site with VRU PG
     */
    private void updateRemoteSite() {
        DataCenter bean = new DataCenter();
        bean.setRefURL(demoSite.getRefURL());
        bean.setChangeStamp(demoSite.getChangeStamp());

        System.out.println("Updating remote site "+demoSite.getName()+" with VRU PG. This may take up to 20 minutes.");

        /*******VRU PG configuration - start**********/
        VruPG vruPG = new VruPG();
        vruPG.setConfigured(true);
        vruPG.setCvp1Address(props.getProperty(REMOTE_SITE_SIDE_A_CVP_ADDRESS));
        vruPG.setCvp2Address(props.getProperty(REMOTE_SITE_SIDE_B_CVP_ADDRESS));
        bean.setVruPG(vruPG);
        /*******VRU PG configuration - end**********/

        restClient.updateAndGetBean(bean);
        System.out.println("Updated remote site "+demoSite.getName()+" with VRU PG successfully.");
    }

    /**
     * Delete the remote site
     */
    private void deleteRemoteSite() {
        System.out.println("Deleting remote site "+demoSite.getName()+". This may take upto 20 minutes.");
        restClient.delete(demoSite.getRefURL());
        System.out.println("Deleted remote site "+demoSite.getName()+" successfully.");
    }
}
