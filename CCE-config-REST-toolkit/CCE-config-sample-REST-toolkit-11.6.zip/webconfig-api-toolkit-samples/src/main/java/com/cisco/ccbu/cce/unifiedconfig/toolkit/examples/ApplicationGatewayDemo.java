package com.cisco.ccbu.cce.unifiedconfig.toolkit.examples;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.ApiException;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.RESTClient;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.bean.*;

import javax.ws.rs.Path;
import java.util.*;

/**
 *
 * Example code for Create and Get , Delete , Update  for Application Gateway
 *
 * Command line launch: mvn exec:java -Dexec.mainClass="com.cisco.ccbu.cce.unifiedconfig.toolkit.examples.ApplicationGatewayDemo" -Dexec.args="10.86.135.193 administrator@test.com abc123="
 */

public class ApplicationGatewayDemo {

    private static final String APPGATEWAY_NAME_PREFIX = "abc";

    public static void main(String[] args) {

        if (args.length < 3) {
            System.out.println("ApplicationGatewayDemo requires 3 parameters: hostname username (with @domain) password");
            System.exit(0);
        }

        // Create a new RESTClient object
        RESTClient restClient = new RESTClient(args[0], args[1], args[2]);

        Deployment deploymentType = restClient.get(Deployment.class, RESTClient.baseUrl + Deployment.class.getAnnotation(Path.class).value());

        System.out.println("System is in Deployment Type: " + deploymentType.getDeploymentType());

        if (deploymentType.getDeploymentType() != 7 && deploymentType.getDeploymentType() != 10) {
            System.out.println("ApplicationGatewayGroupDemo can only be run in PCCE (7) or PCCE_LAB (10) deployments.");
            System.exit(0);
        }

        try{

            applicationGatewayDemo(restClient);
        }catch (ApiException e){
            System.out.println(e.getErrors());
        }

    }

    /**
     * Demo method that demonstrates bean population and the CRUD operation
     */
    private static void applicationGatewayDemo(RESTClient restClient) {

        //populate application gateway bean
        ApplicationGateway bean = populateBean(DemoUtils.generateUniqueString(APPGATEWAY_NAME_PREFIX,1));

        //CREATE and GET
        bean = restClient.createAndGetBean(bean);
        System.out.println("App Gateway created: " + bean.getRefURL() + " Description :"+bean.getDescription());

        //UPDATE
        bean.setDescription("New Description");
        bean=restClient.updateAndGetBean(bean);
        System.out.println("App Gateway updated: " + bean.getRefURL() +" Changed Description:"+ bean.getDescription());

        //DELETE
        System.out.println("Deleting : "+bean.getRefURL());
        restClient.delete(bean.getRefURL());


    }
    /**
     * Method to populate the application gateway bean
     */
    private static ApplicationGateway populateBean(String name)
    {
        ApplicationGateway bean = new ApplicationGateway();
        ApplicationGatewayFaultTolerance faultTolerance=ApplicationGatewayFaultTolerance.NONE;
        ApplicationGatewayPreferredSide appGatewayPreferredSide=ApplicationGatewayPreferredSide.A;
        ApplicationGatewayConnection appGatewayConnection=new ApplicationGatewayConnection();
        appGatewayConnection.setSide(appGatewayPreferredSide);
        appGatewayConnection.setAddress("10.10.8.1");
        appGatewayConnection.setPort(1234);
        List<ApplicationGatewayConnection> connections=new ArrayList<ApplicationGatewayConnection>();
        connections.add(appGatewayConnection);
        bean.setDescription("Sample Description");
        bean.setName(name);
        bean.setFaultTolerance(faultTolerance);
        bean.setEncryption(1);
        bean.setPreferredSide(appGatewayPreferredSide);
        bean.setConnections(connections);
        return bean;

    }

}

