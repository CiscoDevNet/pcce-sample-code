// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum SsoLocalEnabledState {
  NON_SSO,
  SSO,
  HYBRID
}
