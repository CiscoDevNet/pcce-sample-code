// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="sipServerGroupProperties")
public class SIPServerGroupProperties extends BaseApiBean {
  private String optionsOverrideHost;
  private String serverGroupDownInterval;
  private String serverGroupHBLocalListenPort;
  private String serverGroupHBMethod;
  private String serverGroupHBNumTries;
  private String serverGroupHBTimeout;
  private String serverGroupHBTransportType;
  private String serverGroupHeartbeats;
  private String serverGroupOverloadedResponseCodes;
  private String serverGroupUpInterval;

  public String getOptionsOverrideHost() {
     return this.optionsOverrideHost;
  }

  public void setOptionsOverrideHost(String optionsOverrideHost) {
     this.optionsOverrideHost = optionsOverrideHost;
  }

  public String getServerGroupDownInterval() {
     return this.serverGroupDownInterval;
  }

  public void setServerGroupDownInterval(String serverGroupDownInterval) {
     this.serverGroupDownInterval = serverGroupDownInterval;
  }

  public String getServerGroupHBLocalListenPort() {
     return this.serverGroupHBLocalListenPort;
  }

  public void setServerGroupHBLocalListenPort(String serverGroupHBLocalListenPort) {
     this.serverGroupHBLocalListenPort = serverGroupHBLocalListenPort;
  }

  public String getServerGroupHBMethod() {
     return this.serverGroupHBMethod;
  }

  public void setServerGroupHBMethod(String serverGroupHBMethod) {
     this.serverGroupHBMethod = serverGroupHBMethod;
  }

  public String getServerGroupHBNumTries() {
     return this.serverGroupHBNumTries;
  }

  public void setServerGroupHBNumTries(String serverGroupHBNumTries) {
     this.serverGroupHBNumTries = serverGroupHBNumTries;
  }

  public String getServerGroupHBTimeout() {
     return this.serverGroupHBTimeout;
  }

  public void setServerGroupHBTimeout(String serverGroupHBTimeout) {
     this.serverGroupHBTimeout = serverGroupHBTimeout;
  }

  public String getServerGroupHBTransportType() {
     return this.serverGroupHBTransportType;
  }

  public void setServerGroupHBTransportType(String serverGroupHBTransportType) {
     this.serverGroupHBTransportType = serverGroupHBTransportType;
  }

  public String getServerGroupHeartbeats() {
     return this.serverGroupHeartbeats;
  }

  public void setServerGroupHeartbeats(String serverGroupHeartbeats) {
     this.serverGroupHeartbeats = serverGroupHeartbeats;
  }

  public String getServerGroupOverloadedResponseCodes() {
     return this.serverGroupOverloadedResponseCodes;
  }

  public void setServerGroupOverloadedResponseCodes(String serverGroupOverloadedResponseCodes) {
     this.serverGroupOverloadedResponseCodes = serverGroupOverloadedResponseCodes;
  }

  public String getServerGroupUpInterval() {
     return this.serverGroupUpInterval;
  }

  public void setServerGroupUpInterval(String serverGroupUpInterval) {
     this.serverGroupUpInterval = serverGroupUpInterval;
  }


}
