// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@Path("/eccpayload")
@XmlRootElement(name="eccpayload")
public class ECCPayload extends BaseApiBean {
  private Integer changeStamp;
  private String correlationId;
  private ReferenceBean department;
  private String description;
  private String name;
  private String refURL;
  private List<ReferenceBean> variables;

  public Integer getChangeStamp() {
     return this.changeStamp;
  }

  public void setChangeStamp(Integer changeStamp) {
     this.changeStamp = changeStamp;
  }

  public String getCorrelationId() {
     return this.correlationId;
  }

  public void setCorrelationId(String correlationId) {
     this.correlationId = correlationId;
  }

  public ReferenceBean getDepartment() {
     return this.department;
  }

  public void setDepartment(ReferenceBean department) {
     this.department = department;
  }

  public String getDescription() {
     return this.description;
  }

  public void setDescription(String description) {
     this.description = description;
  }

  public String getName() {
     return this.name;
  }

  public void setName(String name) {
     this.name = name;
  }

  public String getRefURL() {
     return this.refURL;
  }

  public void setRefURL(String refURL) {
     this.refURL = refURL;
  }

  @XmlElementWrapper(name="variables")
  @XmlElement(name="variable")
  public List<ReferenceBean> getVariables() {
     return this.variables;
  }

  public void setVariables(List<ReferenceBean> variables) {
     this.variables = variables;
  }


  @Path("/eccpayload")
  @XmlRootElement(name = "results")
  public static class ECCPayloadList extends BaseApiListBean<ECCPayload> {
    @XmlElementWrapper(name = "eccpayloads")
    @XmlElement(name = "eccpayload")
    public List<ECCPayload> getItems() {
      return items;
    }

    public void setItems(List<ECCPayload> items) {
      this.items = items;
    }
  }
}
