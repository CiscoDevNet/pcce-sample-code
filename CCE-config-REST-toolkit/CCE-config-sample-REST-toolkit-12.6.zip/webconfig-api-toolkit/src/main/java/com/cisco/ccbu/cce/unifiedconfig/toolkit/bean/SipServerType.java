// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum SipServerType {
  VRU,
  Agent,
  External
}
