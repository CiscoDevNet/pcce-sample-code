// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum DialingMode {
  INBOUND,
  PREDICTIVEONLY,
  PREVIEWONLY,
  PROGRESSIVEONLY,
  PREVIEWDIRECTONLY
}
