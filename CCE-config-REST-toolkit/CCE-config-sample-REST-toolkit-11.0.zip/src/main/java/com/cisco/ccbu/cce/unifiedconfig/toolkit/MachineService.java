package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "service")
public class MachineService extends BaseApiBean {
    public enum ServiceType {
        TIP_PG,
        TIP_ROUTER,
        ACTIVE_MQ,
        TIP_PG_TOS,
        TIP_ROUTER_TOS,
        STORM_DRPC,
        LIVE_DATA_WEB_SOCKETS,
        LIVE_DATA_API,
        LIVE_DATA_CASSANDRA,
        AW_REST_API,
        ESXI,
        SPOG,
        AXL,
        DIAGNOSTIC_PORTAL,
        ISE_AUTHENTICATION,
        GATEWAY,
        MANAGEMENT_LINK,
        ADMINISTRATION,
        INVALID
    }
    private ServiceType type;
    private Integer port = 0;
    private String uri;
    private String pairing;
    private String userName;
    private String password;
    private String description;

    public ServiceType getType() {
        return type;
    }

    public void setType(ServiceType serviceType) {
        this.type = serviceType;
    }
    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }
    public String getPairing() {
        return pairing;
    }

    public void setPairing(String pairing) {
        this.pairing = pairing;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String serviceURI) {
        this.uri = serviceURI;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

