package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CallManagerRef extends BaseApiBean {
    private String name;
    private String refURL;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getRefURL() {
        return refURL;
    }

    public void setRefURL(String refURL) {
        this.refURL = refURL;
    }
}
