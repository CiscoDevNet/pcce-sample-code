package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Path("machineinventory")
@XmlRootElement(name = "machine")
public class Machine extends BaseApiBean {

    public enum MachineType {
        VM_HOST,
        CCE_DATA_SERVER,
        CCE_CALL_SERVER,
        CVP_OPS,
        CVP,
        CM,
        CM_PUBLISHER,
        CM_SUBSCRIBER,
        CVP_REPORTING,
        CUIC_PUBLISHER,
        CUIC_SUBSCRIBER,
        FINESSE,
        GATEWAY,
        EXTERNAL_SOCIAL_MINER,
        EXTERNAL_CM_PUBLISHER,
        EXTERNAL_CM_SUBSCRIBER,
        EXTERNAL_CVP_REPORTING,
        EXTERNAL_HDS,
        EXTERNAL_MEDIA_SENSE,
        EXTERNAL_EIM_WIM_SERVICES_SERVER,
        EXTERNAL_THIRD_PARTY_MULTICHANNEL,
        CCE_ROUTER,
        CCE_PG,
        LIVE_DATA,
        PRIMARY_AW,
        SECONDARY_AW,
        INVALID
    }
    private String name;
    private MachineType machineType;
    private String hostName;
    private VMHostRef vmHostRef;
    private String vmInstanceUuid;
    private String description;
    private List<MachineAddress> addresses;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlElement(name = "type")
    public MachineType getMachineType() {
        return machineType;
    }

    public void setMachineType(MachineType machineType) {
        this.machineType = machineType;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getVmInstanceUuid() {
        return vmInstanceUuid;
    }

    public void setVmInstanceUuid(String vmInstanceUuid) {
        this.vmInstanceUuid = vmInstanceUuid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlElementWrapper(name = "networks")
    @XmlElement(name = "network")
    public List<MachineAddress> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<MachineAddress> addresses) {
        this.addresses = addresses;
    }

    @XmlElement(name = "vmHost")
    public VMHostRef getVmHostRef() {
        return vmHostRef;
    }

    public void setVmHostRef(VMHostRef vmHostRef) {
        this.vmHostRef = vmHostRef;
    }

    @Path("machineinventory")
    @XmlRootElement(name = "results")
    public static class MachineList extends BaseApiListBean<Machine>{

        @XmlElementWrapper(name = "machines")
        @XmlElement(name = "machine")
        public List<Machine> getItems() {
            return items;
        }

        public void setItems(List<Machine> items) {
            this.items = items;
        }
    }
}
