package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Path("deploymenttypeinfo")
@XmlRootElement(name = "deploymentTypeInfo")
public class DeploymentTypeInfo extends BaseApiBean {
    private Integer deploymentType;
    private List<VMHost> vmHosts;

    public Integer getDeploymentType() {
        return deploymentType;
    }

    public void setDeploymentType(Integer deploymentType) {
        this.deploymentType = deploymentType;
    }

    @XmlElementWrapper(name="vmHosts")
    @XmlElement(name="vmHost")
    public List<VMHost> getVmHosts() {
        return vmHosts;
    }

    public void setVmHosts(List<VMHost> vmHosts) {
        this.vmHosts = vmHosts;
    }
}
