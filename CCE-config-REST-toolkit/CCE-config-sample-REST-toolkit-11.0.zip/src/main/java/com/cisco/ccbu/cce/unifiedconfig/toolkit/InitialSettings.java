package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;

@Path("initialize/settings")
@XmlRootElement
public class InitialSettings extends BaseApiBean {
    private String mobileAgentCodec;
    private CallManagerRef cmSideA;
    private CallManagerRef cmSideB;
    private String serviceAccountUserName;
    private String serviceAccountPassword;

    public String getMobileAgentCodec() {
        return mobileAgentCodec;
    }

    public void setMobileAgentCodec(String mobileAgentCodec) {
        this.mobileAgentCodec = mobileAgentCodec;
    }

    public CallManagerRef getCmSideA() {
        return cmSideA;
    }

    public void setCmSideA(CallManagerRef cmSideA) {
        this.cmSideA = cmSideA;
    }

    public CallManagerRef getCmSideB() {
        return cmSideB;
    }

    public void setCmSideB(CallManagerRef cmSideB) {
        this.cmSideB = cmSideB;
    }

    public String getServiceAccountUserName() {
        return serviceAccountUserName;
    }

    public void setServiceAccountUserName(String userName) {
        this.serviceAccountUserName= userName;
    }

    public String getServiceAccountPassword() {
        return serviceAccountPassword;
    }

    public void setServiceAccountPassword(String password) {
        serviceAccountPassword = password;
    }

}
