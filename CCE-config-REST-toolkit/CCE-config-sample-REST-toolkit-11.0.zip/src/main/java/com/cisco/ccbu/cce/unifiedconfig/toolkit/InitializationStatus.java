package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement
public class InitializationStatus extends BaseApiBean {
    public enum StateEnum {
        NOT_STARTED,
        PROCESSING,
        FAILED,
        FAILED_NEEDS_RETRY,
        SUCCEEDED
    }

    private StateEnum state;
    private String taskName;
    private List<ApiError> apiErrors;

    public StateEnum getState() {
        return state;
    }

    public void setState(StateEnum state) {
        this.state = state;
    }

    @XmlElement(name = "name")
    public String getTaskName() { return taskName; }

    public void setTaskName(String newTaskName) { taskName = newTaskName; }

    @XmlElementWrapper(name = "apiErrors")
    @XmlElement(name = "apiError")
    public List<ApiError> getApiErrors() {
        return apiErrors;
    }

    public void setApiErrors(List<ApiError> apiErrors) {
        this.apiErrors = apiErrors;
    }

    @Path("initialize")
    @XmlRootElement(name = "results")
    public static class InitializationStatusList extends BaseApiListBean<InitializationStatus> {
        private StateEnum state;

        /**
         * @return The overall initialization state of the system.
         */
        public StateEnum getState() {
            return state;
        }

        /**
         * @param state The overall initialization state of the system.
         */
        public void setState(StateEnum state) {
            this.state = state;
        }

        @XmlElementWrapper(name = "initializationStatuses")
        @XmlElement(name = "initializationStatus")
        public List<InitializationStatus> getItems() {
            return items;
        }

        public void setItems(List<InitializationStatus> items) {
            this.items = items;
        }
    }
}
