package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;

@Path("deployment")
@XmlRootElement(name = "deployment")
public class Deployment extends BaseApiBean {

    private Integer deploymentType;

    public Integer getDeploymentType() {
        return deploymentType;
    }

    public void setDeploymentType(Integer deploymentType) {
        this.deploymentType = deploymentType;
    }
}
