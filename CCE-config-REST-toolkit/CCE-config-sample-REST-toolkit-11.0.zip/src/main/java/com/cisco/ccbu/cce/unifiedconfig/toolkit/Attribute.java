package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Path("attribute")
@XmlRootElement(name = "attribute")
public class Attribute extends BaseApiBean {

    private String name;
    private String description;
    private String dataType;
    private String defaultValue;

    private ReferenceBean department;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String desc) {
        this.description = desc;
    }

    @SuppressWarnings("UnusedDeclaration")
    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public ReferenceBean getDepartment() {
        return department;
    }

    public void setDepartment(ReferenceBean department) {
        this.department = department;
    }

    /**
     * List bean for Attribute API.
     */
    @Path("attribute")
    @XmlRootElement(name = "results")
    public static class AttributeList extends BaseApiListBean<Attribute>{

        @XmlElementWrapper(name = "attributes")
        @XmlElement(name = "attribute")
        public List<Attribute> getItems() {
            return items;
        }

        public void setItems(List<Attribute> items) {
            this.items = items;
        }
    }
}
