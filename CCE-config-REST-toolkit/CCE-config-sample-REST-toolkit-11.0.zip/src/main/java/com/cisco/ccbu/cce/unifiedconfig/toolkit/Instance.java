package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;

@Path("instance")
@XmlRootElement(name = "instance")
public class Instance extends BaseApiBean {
    private String domainName;

    private String domainNameDN;

    private String facilityName;

    private String facilityNameDN;

    private String instanceName;

    private String instanceNameDN;

    private Integer instanceNumber;

    private Boolean existsInAD;

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getDomainNameDN() {
        return domainNameDN;
    }

    public void setDomainNameDN(String domainNameDN) {
        this.domainNameDN = domainNameDN;
    }

    public String getFacilityName() {
        return facilityName;
    }

    public void setFacilityName(String facilityName) {
        this.facilityName = facilityName;
    }

    public String getFacilityNameDN() {
        return facilityNameDN;
    }

    public void setFacilityNameDN(String facilityNameDN) {
        this.facilityNameDN = facilityNameDN;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getInstanceNameDN() {
        return instanceNameDN;
    }

    public void setInstanceNameDN(String instanceNameDN) {
        this.instanceNameDN = instanceNameDN;
    }

    public Integer getInstanceNumber() {
        return instanceNumber;
    }

    public void setInstanceNumber(Integer instanceNumber) {
        this.instanceNumber = instanceNumber;
    }

    public Boolean getExistsInAD() {
        return existsInAD;
    }

    public void setExistsInAD(Boolean existsInAD) {
        this.existsInAD = existsInAD;
    }

}
