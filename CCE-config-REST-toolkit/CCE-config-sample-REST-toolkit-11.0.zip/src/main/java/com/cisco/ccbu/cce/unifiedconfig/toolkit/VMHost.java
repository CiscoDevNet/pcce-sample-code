package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="vmHost")
public class VMHost {
    private String name;
    private String address;
    private String userName;
    private String password;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
