package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "address")
public class MachineAddress extends BaseApiBean {
    public enum AddressType {
        PUBLIC,
        PRIVATE,
        INVALID
    }
    private AddressType type;
    private String address;
    private List<MachineService> services;

    public AddressType getType() {
        return type;
    }

    public void setType(AddressType addressType) {
        this.type = addressType;
    }
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlElementWrapper(name = "services")
    @XmlElement(name = "service")
    public List<MachineService> getMachineServices(){
        return services;
    }

    public void setMachineServices(List<MachineService> services){
        this.services = services;
    }
}
