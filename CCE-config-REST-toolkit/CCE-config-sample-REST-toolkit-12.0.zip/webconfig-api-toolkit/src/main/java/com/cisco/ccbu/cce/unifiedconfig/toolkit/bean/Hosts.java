// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@Path("machineinfo")
@XmlRootElement(name="Hosts")
public class Hosts extends BaseApiBean {
  private List<String> host;

  public List<String> getHost() {
     return this.host;
  }

  public void setHost(List<String> host) {
     this.host = host;
  }


  @Path("machineinfo")
  @XmlRootElement(name = "results")
  public static class HostsList extends BaseApiListBean<Hosts> {
    @XmlElementWrapper(name = "Hostss")
    @XmlElement(name = "Hosts")
    public List<Hosts> getItems() {
      return items;
    }

    public void setItems(List<Hosts> items) {
      this.items = items;
    }
  }
}
