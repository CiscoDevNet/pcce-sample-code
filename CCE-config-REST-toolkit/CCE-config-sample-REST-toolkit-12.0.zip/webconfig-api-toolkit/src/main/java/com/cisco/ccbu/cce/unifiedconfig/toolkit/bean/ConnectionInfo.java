// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@Path("connectioninfo")
@XmlRootElement(name="connectionInfo")
public class ConnectionInfo extends BaseApiBean {
  private String address;
  private String authString;
  private String correlationId;
  private ReferenceBean department;
  private Integer id;
  private int port;
  private String refURL;

  @XmlElement(name="address")
  public String getAddress() {
     return this.address;
  }

  public void setAddress(String address) {
     this.address = address;
  }

  @XmlElement(name="authString")
  public String getAuthString() {
     return this.authString;
  }

  public void setAuthString(String authString) {
     this.authString = authString;
  }

  public String getCorrelationId() {
     return this.correlationId;
  }

  public void setCorrelationId(String correlationId) {
     this.correlationId = correlationId;
  }

  public ReferenceBean getDepartment() {
     return this.department;
  }

  public void setDepartment(ReferenceBean department) {
     this.department = department;
  }

  public Integer getId() {
     return this.id;
  }

  public void setId(Integer id) {
     this.id = id;
  }

  @XmlElement(name="port")
  public int getPort() {
     return this.port;
  }

  public void setPort(int port) {
     this.port = port;
  }

  public String getRefURL() {
     return this.refURL;
  }

  public void setRefURL(String refURL) {
     this.refURL = refURL;
  }


  @Path("connectioninfo")
  @XmlRootElement(name = "results")
  public static class ConnectionInfoList extends BaseApiListBean<ConnectionInfo> {
    @XmlElementWrapper(name = "connectionInfos")
    @XmlElement(name = "connectionInfo")
    public List<ConnectionInfo> getItems() {
      return items;
    }

    public void setItems(List<ConnectionInfo> items) {
      this.items = items;
    }
  }
}
