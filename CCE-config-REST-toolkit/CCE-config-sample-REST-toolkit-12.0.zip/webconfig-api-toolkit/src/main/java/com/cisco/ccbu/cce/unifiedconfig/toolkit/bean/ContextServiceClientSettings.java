// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="ContextServiceClientSettings")
public class ContextServiceClientSettings extends BaseApiBean {
  private Boolean labMode;
  private Boolean proxyEnable;
  private String proxyUrl;
  private int requestTimeout;

  public Boolean getLabMode() {
     return this.labMode;
  }

  public void setLabMode(Boolean labMode) {
     this.labMode = labMode;
  }

  public Boolean getProxyEnable() {
     return this.proxyEnable;
  }

  public void setProxyEnable(Boolean proxyEnable) {
     this.proxyEnable = proxyEnable;
  }

  public String getProxyUrl() {
     return this.proxyUrl;
  }

  public void setProxyUrl(String proxyUrl) {
     this.proxyUrl = proxyUrl;
  }

  public int getRequestTimeout() {
     return this.requestTimeout;
  }

  public void setRequestTimeout(int requestTimeout) {
     this.requestTimeout = requestTimeout;
  }


}
