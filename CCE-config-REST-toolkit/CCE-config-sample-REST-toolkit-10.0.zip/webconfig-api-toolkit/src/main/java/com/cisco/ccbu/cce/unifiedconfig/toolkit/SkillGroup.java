package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Path("skillgroup")
@XmlRootElement(name = "skillGroup")
public class SkillGroup extends BaseApiBean{

    private String name;
    private String description;

    private Integer serviceLevelThreshold;
    private Integer serviceLevelType;

//    private List<AgentRefWithTeam> agents;
//    private MediaRoutingDomainRef mediaRoutingDomain;
//    private BucketIntervalRef bucketInterval;

    private ReferenceBean department;

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public Integer getServiceLevelThreshold()
    {
        return serviceLevelThreshold;
    }

    public void setServiceLevelThreshold(Integer serviceLevelThreshold)
    {
        this.serviceLevelThreshold = serviceLevelThreshold;
    }

    public Integer getServiceLevelType()
    {
        return serviceLevelType;
    }

    public void setServiceLevelType(Integer serviceLevelType)
    {
        this.serviceLevelType = serviceLevelType;
    }

//    public List<AgentRefWithTeam> getAgents()
//    {
//        return agents;
//    }
//
//    public void setAgents(List<AgentRefWithTeam> agents)
//    {
//        this.agents = agents;
//    }
//
//    public MediaRoutingDomainRef getMediaRoutingDomain()
//    {
//        return mediaRoutingDomain;
//    }
//
//    public void setMediaRoutingDomain(MediaRoutingDomainRef mediaRoutingDomain)
//    {
//        this.mediaRoutingDomain = mediaRoutingDomain;
//    }
//
//    public BucketIntervalRef getBucketInterval()
//    {
//        return bucketInterval;
//    }
//
//    public void setBucketInterval(BucketIntervalRef bucketInterval)
//    {
//        this.bucketInterval = bucketInterval;
//    }

    public ReferenceBean getDepartment(){
        return department;
    }

    public void setDepartment(ReferenceBean department){
        this.department = department;
    }

    /**
     * List bean for SkillGroup API.
     */
    @Path("skillgroup")
    @XmlRootElement(name = "results")
    public static class SkillGroupList extends BaseApiListBean<SkillGroup>{

        @XmlElementWrapper(name = "skillGroups")
        @XmlElement(name = "skillGroup")
        public List<SkillGroup> getItems() {
            return items;
        }

        public void setItems(List<SkillGroup> items) {
            this.items = items;
        }
    }
}
