package com.cisco.ccbu.cce.unifiedconfig.toolkit;

/**
 * Base Bean for making REST API call.
 */
public abstract class BaseApiBean extends BaseBean{

    private String refURL;
    private Integer changeStamp;

    public Integer getChangeStamp() {
        return changeStamp;
    }

    public void setChangeStamp(Integer changeStamp) {
        this.changeStamp = changeStamp;
    }

    public String getRefURL() {
        return refURL;
    }

    public void setRefURL(String refURL) {
        this.refURL = refURL;
    }

}
