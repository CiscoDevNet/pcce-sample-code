package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Path("agent")
@XmlRootElement(name = "agent")
public class Agent extends BaseApiBean {

    // instance variables
    private Person person;
    private String description;
    private String agentId;
    private Boolean agentStateTrace;

    private Boolean supervisor;

    private List<ReferenceBean> skillGroups;
    private ReferenceBean defaultSkillGroup;
    private ReferenceBean agentTeam;
    private ReferenceBean agentDeskSettings;
    private List<AgentAttribute> attributes;
    private List<ReferenceBean> supervisorTeams;

    private ReferenceBean department;

    public String getDescription() {
        return description;
    }

    public void setDescription(String desc) {
        this.description = desc;
    }

    public Boolean getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Boolean supervisor) {
        this.supervisor = supervisor;
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId;
    }

    public Boolean getAgentStateTrace() {
        return agentStateTrace;
    }

    public void setAgentStateTrace(Boolean stateTrace) {
        this.agentStateTrace = stateTrace;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public ReferenceBean getAgentTeam() {
        return agentTeam;
    }

    public void setAgentTeam(ReferenceBean team) {
        this.agentTeam = team;
    }

    public ReferenceBean getAgentDeskSettings(){
        return agentDeskSettings;
    }

    public void setAgentDeskSettings(ReferenceBean agentDeskSettings){
        this.agentDeskSettings = agentDeskSettings;
    }

    public ReferenceBean getDefaultSkillGroup(){
        return defaultSkillGroup;
    }

    public void setDefaultSkillGroup(ReferenceBean defaultSkillGroup){
        this.defaultSkillGroup = defaultSkillGroup;
    }

    @XmlElementWrapper(name="agentAttributes")
    @XmlElement(name="agentAttribute")
    public List<AgentAttribute> getAttributes(){
        return attributes;
    }

    public void setAttributes(List<AgentAttribute> attributes){
        this.attributes = attributes;
    }

    @XmlElementWrapper(name = "skillGroups")
    @XmlElement(name = "skillGroup")
    public List<ReferenceBean> getSkillGroups(){
        return skillGroups;
    }

    public void setSkillGroups(List<ReferenceBean> skillGroups){
        this.skillGroups = skillGroups;
    }

    @XmlElementWrapper(name = "supervisorTeams")
    @XmlElement(name = "supervisorTeam")
    public List<ReferenceBean> getSupervisorTeams(){
        return supervisorTeams;
    }

    public void setSupervisorTeams(List<ReferenceBean> supervisorTeams){
        this.supervisorTeams = supervisorTeams;
    }

    public ReferenceBean getDepartment() {
        return department;
    }

    public void setDepartment(ReferenceBean department) {
        this.department = department;
    }

    public static class Person extends BaseBean{

        private String userName;
        private String firstName;
        private String lastName;
        private Boolean loginEnabled;
        private String password;  // clear-text password sent into api
        private String description;

        public String getDescription() {
            return description;
        }

        public void setDescription(String desc) {
            this.description = desc;
        }


        public String getUserName() {
            return userName;
        }

        public void setUserName(String name) {
            this.userName = name;
        }

        public Boolean getLoginEnabled()
        {
            return loginEnabled;
        }

        public void setLoginEnabled(Boolean loginEnabled)
        {
            this.loginEnabled = loginEnabled;
        }

        public String getPassword()
        {
            return password;
        }

        public void setPassword(String password)
        {
            this.password = password;
        }

        public String getFirstName()
        {
            return firstName;
        }

        public void setFirstName(String firstName)
        {
            this.firstName = firstName;
        }

        public String getLastName()
        {
            return lastName;
        }

        public void setLastName(String lastName)
        {
            this.lastName = lastName;
        }
    }

    public static class AgentAttribute extends BaseBean{

        private String description;
        private String attributeValue;
        private ReferenceBean attribute;

        public AgentAttribute(){

        }

        public AgentAttribute(String attributeValue, ReferenceBean attribute){
            this.attributeValue = attributeValue;
            this.attribute = attribute;
        }

        public String getDescription(){
            return description;
        }

        public void setDescription(String description){
            this.description = description;
        }

        public String getAttributeValue(){
            return attributeValue;
        }

        public void setAttributeValue(String attributeValue){
            this.attributeValue = attributeValue;
        }

        public ReferenceBean getAttribute(){
            return attribute;
        }

        public void setAttribute(ReferenceBean attribute){
            this.attribute = attribute;
        }
    }

    /**
     * List bean for Agent API.
     */
    @Path("agent")
    @XmlRootElement(name = "results")
    public static class AgentList extends BaseApiListBean<Agent>{

        @XmlElementWrapper(name = "agents")
        @XmlElement(name = "agent")
        public List<Agent> getItems() {
            return items;
        }

        public void setItems(List<Agent> items) {
            this.items = items;
        }
    }

}
