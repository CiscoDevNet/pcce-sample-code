package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Tests for the SkillGroup API
 */
public class SkillGroupBeanTest extends BaseApiBeanTest {
    public Class<? extends BaseApiListBean> getListBeanClass(){
        return SkillGroup.SkillGroupList.class;
    }

    public Class<? extends BaseApiBean> getBeanClass(){
        return SkillGroup.class;
    }

    public SkillGroup generateBeanForCreate(String identifier){
        SkillGroup skillGroup = new SkillGroup();

        skillGroup.setName(generateUniqueString(identifier));
        skillGroup.setDescription("desc");

        return skillGroup;
    }

    public Map<String, Object> generateBeanForInvalidCreate(){
        SkillGroup skillGroup = new SkillGroup();
        skillGroup.setName("");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "name", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", skillGroup);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }

    public SkillGroup modifyBeanForUpdate(BaseApiBean beanToUpdate){
        SkillGroup skillGroup = (SkillGroup)beanToUpdate;

        skillGroup.setDescription("updated bean");

        return skillGroup;
    }

    public Map<String, Object> modifyBeanForInvalidUpdate(BaseApiBean beanToUpdate){
        SkillGroup skillGroup = (SkillGroup)beanToUpdate;
        skillGroup.setName("");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "name", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", skillGroup);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }
}
