package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.cisco.ccbu.cce.unifiedconfig.toolkit.Agent.Person;

/**
 * Tests for the Agent API
 */
public class AgentBeanTest extends BaseApiBeanTest {
    public Class<? extends BaseApiListBean> getListBeanClass(){
        return Agent.AgentList.class;
    }

    public Class<? extends BaseApiBean> getBeanClass(){
        return Agent.class;
    }

    public Agent generateBeanForCreate(String identifier){
        Agent agent = new Agent();

        Person person = new Person();
        person.setFirstName(generateUniqueString(identifier));
        person.setLastName(generateUniqueString(identifier));
        person.setUserName(generateUniqueString(identifier));
        person.setLoginEnabled(true);

        agent.setPerson(person);
        agent.setSupervisor(false);
        agent.setAgentId(generateUniqueNumberString(11));
        agent.setAgentStateTrace(false);
        agent.setDescription("desc");

        return agent;
    }

    public Map<String, Object> generateBeanForInvalidCreate(){
        Agent agent = new Agent();

        Person person = new Person();
        person.setFirstName("");
        person.setLastName(generateUniqueString("lastName"));
        person.setUserName(generateUniqueString("userName"));
        person.setLoginEnabled(true);

        agent.setPerson(person);
        agent.setSupervisor(false);
        agent.setAgentId(generateUniqueNumberString(11));
        agent.setAgentStateTrace(false);
        agent.setDescription("desc");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "firstName", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", agent);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }

    public Agent modifyBeanForUpdate(BaseApiBean beanToUpdate){
        Agent agent = (Agent)beanToUpdate;

        agent.setAgentId(generateUniqueNumberString(10));
        agent.setDescription("updated bean");

        return agent;
    }

    public Map<String, Object> modifyBeanForInvalidUpdate(BaseApiBean beanToUpdate){
        Agent agent = (Agent)beanToUpdate;
        agent.getPerson().setFirstName("");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "firstName", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", agent);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }
}
