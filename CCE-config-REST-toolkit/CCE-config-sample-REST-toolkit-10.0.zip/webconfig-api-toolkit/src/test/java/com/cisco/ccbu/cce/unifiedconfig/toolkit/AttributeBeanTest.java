package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Tests for the Attribute API
 */
public class AttributeBeanTest extends BaseApiBeanTest {
    public Class<? extends BaseApiListBean> getListBeanClass(){
        return Attribute.AttributeList.class;
    }

    public Class<? extends BaseApiBean> getBeanClass(){
        return Attribute.class;
    }

    public Attribute generateBeanForCreate(String identifier){
        Attribute attribute = new Attribute();

        attribute.setName(generateUniqueString(identifier));
        attribute.setDescription("desc");
        attribute.setDataType("3");
        attribute.setDefaultValue("true");

        return attribute;
    }

    public Map<String, Object> generateBeanForInvalidCreate(){
        Attribute attribute = new Attribute();
        attribute.setName("");
        attribute.setDataType("3");
        attribute.setDefaultValue("true");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "name", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", attribute);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }

    public Attribute modifyBeanForUpdate(BaseApiBean beanToUpdate){
        Attribute attribute = (Attribute)beanToUpdate;
        attribute.setDescription("updated bean");

        return attribute;
    }

    public Map<String, Object> modifyBeanForInvalidUpdate(BaseApiBean beanToUpdate){
        Attribute attribute = (Attribute)beanToUpdate;
        attribute.setName("");

        ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                new ApiError("invalidInput.fieldRequired", "name", "This field is required and cannot be empty.")
        )));

        Map<String, Object> returnObj = new HashMap<String, Object>();
        returnObj.put("bean", attribute);
        returnObj.put("errors", expectedErrs);
        return returnObj;
    }
}
