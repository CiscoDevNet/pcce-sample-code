package com.cisco.ccbu.cce.unifiedconfig.toolkit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.ws.rs.Path;
import java.util.*;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

/**
 * Base class for API Tests
 */
public abstract class BaseApiBeanTest {

    protected static RESTClient client = null;
    protected static List<String> refList = new ArrayList<String>();
    private static int uniqueBase = ((int)( new Date().getTime() / 1000 )) % 10000;
    private static int count = 1;

    @BeforeClass
    public static void beforeClass(){

        String host = System.getProperty("testbed");
        String userName = System.getProperty("username");
        String password = System.getProperty("password");

        assertNotNull("The Testbed IP or hostname must be specified to run Functional Tests", host);
        assertNotNull("The Testbed username must be specified to run Functional Tests", userName);
        assertNotNull("The Testbed password must be specified to run Functional Tests", password);

        client = new RESTClient(host, userName, password);
    }

    @Before
    public void before(){
        refList = new ArrayList<String>();
    }

    @After
    public void after(){
        for(String ref : refList){
            client.delete(ref);
        }
    }

    /**
     * Wrapper around create and get so that we can keep a list of items to be deleted.
     * @param bean
     * @param <T>
     * @return
     */
    protected <T extends BaseApiBean> String createAndGetId(T bean){
        String ref = client.createAndGet(bean);
        refList.add(ref);
        return ref;
    }

    protected static String generateUniqueString(String base){
        return String.format("%s_%03d_%05d", base, uniqueBase, count++);
    }

    protected static String generateUniqueNumberString(int length){
        char[] characters = {'1','2','3','4','5','6','7','8','9'};
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        int max = characters.length;

        for(int i = 0; i < length; i++){
            sb.append(characters[rnd.nextInt(max)]);
        }

        return sb.toString();
    }

    public abstract Class<? extends BaseApiListBean> getListBeanClass();
    public abstract Class<? extends BaseApiBean> getBeanClass();
    public abstract <T extends BaseApiBean> T generateBeanForCreate(String identifier);
    public abstract Map<String, Object> generateBeanForInvalidCreate();
    public abstract <T extends BaseApiBean> T modifyBeanForUpdate(BaseApiBean beanToUpdate);
    public abstract Map<String, Object> modifyBeanForInvalidUpdate(BaseApiBean beanToUpdate);

    @Test
    public void testCreateAndGetList() throws Exception{
        String uniqueIdentifier = generateUniqueString("t");

        // create 5 items
        List<String> refs = new ArrayList<String>();
        for(int i = 0; i < 5; i++){
            BaseApiBean bean = generateBeanForCreate(uniqueIdentifier);
            refs.add(createAndGetId(bean));
        }

        // do a list and assert that they are in the list.
        BaseApiListBean listBean = client.getList(getListBeanClass());

        for(BaseApiBean b : (List<BaseApiBean>)listBean.getItems()){
            if(refs.contains(b.getRefURL()));
            refs.remove(b.getRefURL());
        }

        assertTrue("All of the created items were not found in the list." + refs, refs.size() == 0);
    }

    @Test
    public void testCreateAndGetListWithSearch() throws Exception{
        String uniqueIdentifier = generateUniqueString("t");

        // create 5 items
        int numberOfItems = 5;
        List<String> refs = new ArrayList<String>();
        for(int i = 0; i < numberOfItems; i++){
            BaseApiBean bean = generateBeanForCreate(uniqueIdentifier);
            refs.add(createAndGetId(bean));
        }

        // do a list with our unique identifier and assert that they are in the list.
        BaseApiListBean listBean = client.getList(getListBeanClass(), uniqueIdentifier);

        for(BaseApiBean b : (List<BaseApiBean>)listBean.getItems()){
            if(refs.contains(b.getRefURL()));
            refs.remove(b.getRefURL());
        }

        assertTrue("The size of the query results should be the same as the number created.", listBean.getItems().size() == numberOfItems);
        assertTrue("All of the created items were not found in the list." + refs, refs.size() == 0);
    }

    @Test
    public void testCreateAndGet(){
        String uniqueIdentifier = generateUniqueString("t");

        // create 1 item
        BaseApiBean bean = generateBeanForCreate(uniqueIdentifier);
        String ref = createAndGetId(bean);

        // get the item.
        BaseApiBean returnBean = client.get(getBeanClass(), ref);

        // set the changestamp and refUrl on the created item since these are generated when the bean is returned.
        bean.setChangeStamp(0);
        bean.setRefURL(ref);

        // compare the original bean with the returned bean.
        assertEquals("The returned bean did not match the expected bean.", bean, returnBean);
    }

    @Test
    public void testUpdate(){
        String uniqueIdentifier = generateUniqueString("t");

        // create 1 item
        String ref = createAndGetId(generateBeanForCreate(uniqueIdentifier));

        // do a get and assert that they are in the list.
        BaseApiBean beanToBeUpdated = client.get(getBeanClass(), ref);
        modifyBeanForUpdate(beanToBeUpdated);
        client.update(beanToBeUpdated);

        // update the change stamp on the original object since it should have been increased by the server.
        // this is so that when we do our compare, it doesn't fail because of expected changeStamp incrementation
        beanToBeUpdated.setChangeStamp(1);

        // get a new copy of the bean and compare it to what we submitted to the request.
        BaseApiBean beanAfterUpdate = client.get(getBeanClass(), ref);
        assertEquals("The returned bean did not match the expected bean.", beanToBeUpdated, beanAfterUpdate);
    }

    @Test
    public void testDelete(){
        String uniqueIdentifier = generateUniqueString("t");

        // create 1 item
        String ref = createAndGetId(generateBeanForCreate(uniqueIdentifier));

        // delete it
        client.delete(ref);

        // if we get here, the delete was successful, so lets remove the item from our to-be-deleted list,
        // so we dont try to delete it twice
        refList.remove(ref);
    }

    @Test
    public void testGetWithInvalidId(){
        // try and get an invalid Id, should error
        try{
            client.get(getBeanClass(), client.baseUrl + getBeanClass().getAnnotation(Path.class).value() + "/" + "99999");
            fail("The item should not have been found.");
        } catch(ApiException e){
            // assert that our expected errors are the ones we got.
            ApiErrors expectedErrs = new ApiErrors(new ArrayList<ApiError>(Arrays.asList(
                    new ApiError("notFound.dbData", null, "The specified URL does not exist.")
            )));
            assertEquals("The errors received were not the ones we expected!", expectedErrs, e.getErrors());
        }
    }

    @Test
    public void testInvalidCreate(){
        // create 1 item
        Map<String, Object> testMap = generateBeanForInvalidCreate();
        BaseApiBean bean = (BaseApiBean)testMap.get("bean");

        try{
            String ref = client.createAndGet(bean);
            refList.add(ref);
            fail("The item should not have been created.");
        } catch(ApiException e){
            // assert that our expected errors are the ones we got.
            ApiErrors expectedErrs = (ApiErrors)testMap.get("errors");
            assertEquals("The errors received were not the ones we expected!", expectedErrs, e.getErrors());
        }
    }

    @Test
    public void testInvalidUpdate(){
        String uniqueIdentifier = generateUniqueString("t");

        // create 1 item
        String ref = createAndGetId(generateBeanForCreate(uniqueIdentifier));

        // do a get and assert that they are in the list.
        BaseApiBean beanToBeUpdated = client.get(getBeanClass(), ref);
        Map<String, Object> testMap = modifyBeanForInvalidUpdate(beanToBeUpdated);

        try{
            client.update(beanToBeUpdated);
            fail("The item should not have been updated.");
        } catch(ApiException e){
            // assert that our expected errors are the ones we got.
            ApiErrors expectedErrs = (ApiErrors)testMap.get("errors");
            assertEquals("The errors received were not the ones we expected!", expectedErrs, e.getErrors());
        }
    }
}
