// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="application")
public class Application extends BaseApiBean {
  private String applicationName;
  private String customErrorPrompt;
  private Boolean enableSecurity;
  private Integer maximumSession;
  private Integer sigDigits;
  private SipTrigger sipTrigger;

  public String getApplicationName() {
     return this.applicationName;
  }

  public void setApplicationName(String applicationName) {
     this.applicationName = applicationName;
  }

  public String getCustomErrorPrompt() {
     return this.customErrorPrompt;
  }

  public void setCustomErrorPrompt(String customErrorPrompt) {
     this.customErrorPrompt = customErrorPrompt;
  }

  public Boolean getEnableSecurity() {
     return this.enableSecurity;
  }

  public void setEnableSecurity(Boolean enableSecurity) {
     this.enableSecurity = enableSecurity;
  }

  public Integer getMaximumSession() {
     return this.maximumSession;
  }

  public void setMaximumSession(Integer maximumSession) {
     this.maximumSession = maximumSession;
  }

  public Integer getSigDigits() {
     return this.sigDigits;
  }

  public void setSigDigits(Integer sigDigits) {
     this.sigDigits = sigDigits;
  }

  public SipTrigger getSipTrigger() {
     return this.sipTrigger;
  }

  public void setSipTrigger(SipTrigger sipTrigger) {
     this.sipTrigger = sipTrigger;
  }


}
