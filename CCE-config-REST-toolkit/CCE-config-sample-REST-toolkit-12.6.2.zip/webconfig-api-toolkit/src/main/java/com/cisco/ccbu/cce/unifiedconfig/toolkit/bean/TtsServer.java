// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="ttsServer")
public class TtsServer extends BaseApiBean {
  private int portNumber;
  private String providerName;
  private String self;
  private Integer ttsServerId;
  private String ttsServerName;

  public int getPortNumber() {
     return this.portNumber;
  }

  public void setPortNumber(int portNumber) {
     this.portNumber = portNumber;
  }

  public String getProviderName() {
     return this.providerName;
  }

  public void setProviderName(String providerName) {
     this.providerName = providerName;
  }

  public String getSelf() {
     return this.self;
  }

  public void setSelf(String self) {
     this.self = self;
  }

  public Integer getTtsServerId() {
     return this.ttsServerId;
  }

  public void setTtsServerId(Integer ttsServerId) {
     this.ttsServerId = ttsServerId;
  }

  public String getTtsServerName() {
     return this.ttsServerName;
  }

  public void setTtsServerName(String ttsServerName) {
     this.ttsServerName = ttsServerName;
  }


}
