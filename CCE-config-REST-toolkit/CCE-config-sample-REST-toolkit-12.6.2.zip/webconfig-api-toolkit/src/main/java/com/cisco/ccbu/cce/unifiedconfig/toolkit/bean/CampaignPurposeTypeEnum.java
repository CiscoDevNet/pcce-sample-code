// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum CampaignPurposeTypeEnum {
  agentCampaign,
  ivrCampaign
}
