// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum ReservationType {
  DEFAULT,
  RESERVATION_ENABLED,
  INVALID
}
