// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum StateEnum {
  NOT_STARTED,
  PROCESSING,
  FAILED,
  FAILED_NEEDS_RETRY,
  SUCCEEDED
}
