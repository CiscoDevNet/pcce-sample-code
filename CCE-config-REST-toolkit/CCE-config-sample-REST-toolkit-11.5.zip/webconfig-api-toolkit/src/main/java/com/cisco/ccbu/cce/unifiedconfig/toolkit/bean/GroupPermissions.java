// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum GroupPermissions {
  MYGROUP_NONE_ALLUSERS_NONE,
  MYGROUP_EXEC,
  MYGROUP_EXEC_WRITE,
  MYGROUP_EXEC_ALLUSERS_EXEC,
  MYGROUP_EXEC_WRITE_ALLUSERS_EXEC,
  MYGROUP_EXEC_WRITE_ALLUSERS_EXEC_WRITE
}
