// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="weekDaySchedule")
public class WeekDaySchedule extends BaseApiBean {
  private Integer changeStamp;
  private String correlationId;
  private Integer dayOfWeek;
  private ReferenceBean department;
  private String endTime;
  private String refURL;
  private String startTime;

  public Integer getChangeStamp() {
     return this.changeStamp;
  }

  public void setChangeStamp(Integer changeStamp) {
     this.changeStamp = changeStamp;
  }

  public String getCorrelationId() {
     return this.correlationId;
  }

  public void setCorrelationId(String correlationId) {
     this.correlationId = correlationId;
  }

  public Integer getDayOfWeek() {
     return this.dayOfWeek;
  }

  public void setDayOfWeek(Integer dayOfWeek) {
     this.dayOfWeek = dayOfWeek;
  }

  public ReferenceBean getDepartment() {
     return this.department;
  }

  public void setDepartment(ReferenceBean department) {
     this.department = department;
  }

  public String getEndTime() {
     return this.endTime;
  }

  public void setEndTime(String endTime) {
     this.endTime = endTime;
  }

  public String getRefURL() {
     return this.refURL;
  }

  public void setRefURL(String refURL) {
     this.refURL = refURL;
  }

  public String getStartTime() {
     return this.startTime;
  }

  public void setStartTime(String startTime) {
     this.startTime = startTime;
  }


}
