// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="sipTrigger")
public class SipTrigger extends BaseApiBean {
  private NameUriPair application;
  private NameUriPair callControlGroup;
  private String description;
  private String directoryNumber;
  private Integer idleTimeout;
  private String locale;
  private OverrideMediaTermination overrideMediaTermination;
  private AtomLink self;
  private Boolean triggerEnabled;

  public NameUriPair getApplication() {
     return this.application;
  }

  public void setApplication(NameUriPair application) {
     this.application = application;
  }

  public NameUriPair getCallControlGroup() {
     return this.callControlGroup;
  }

  public void setCallControlGroup(NameUriPair callControlGroup) {
     this.callControlGroup = callControlGroup;
  }

  public String getDescription() {
     return this.description;
  }

  public void setDescription(String description) {
     this.description = description;
  }

  public String getDirectoryNumber() {
     return this.directoryNumber;
  }

  public void setDirectoryNumber(String directoryNumber) {
     this.directoryNumber = directoryNumber;
  }

  public Integer getIdleTimeout() {
     return this.idleTimeout;
  }

  public void setIdleTimeout(Integer idleTimeout) {
     this.idleTimeout = idleTimeout;
  }

  public String getLocale() {
     return this.locale;
  }

  public void setLocale(String locale) {
     this.locale = locale;
  }

  public OverrideMediaTermination getOverrideMediaTermination() {
     return this.overrideMediaTermination;
  }

  public void setOverrideMediaTermination(OverrideMediaTermination overrideMediaTermination) {
     this.overrideMediaTermination = overrideMediaTermination;
  }

  public AtomLink getSelf() {
     return this.self;
  }

  public void setSelf(AtomLink self) {
     this.self = self;
  }

  public Boolean getTriggerEnabled() {
     return this.triggerEnabled;
  }

  public void setTriggerEnabled(Boolean triggerEnabled) {
     this.triggerEnabled = triggerEnabled;
  }


}
