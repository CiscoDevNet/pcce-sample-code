// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="contextservice")
public class ContextService extends BaseApiBean {
  private String connectionData;
  private String labMode;
  private String proxyUrl;
  private String timeOut;

  public String getConnectionData() {
     return this.connectionData;
  }

  public void setConnectionData(String connectionData) {
     this.connectionData = connectionData;
  }

  public String getLabMode() {
     return this.labMode;
  }

  public void setLabMode(String labMode) {
     this.labMode = labMode;
  }

  public String getProxyUrl() {
     return this.proxyUrl;
  }

  public void setProxyUrl(String proxyUrl) {
     this.proxyUrl = proxyUrl;
  }

  public String getTimeOut() {
     return this.timeOut;
  }

  public void setTimeOut(String timeOut) {
     this.timeOut = timeOut;
  }


}
