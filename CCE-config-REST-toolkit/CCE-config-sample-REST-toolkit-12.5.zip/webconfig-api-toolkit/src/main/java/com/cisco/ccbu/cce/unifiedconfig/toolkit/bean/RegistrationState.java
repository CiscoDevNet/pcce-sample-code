// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum RegistrationState {
  notRegistered,
  registered,
  invalid
}
