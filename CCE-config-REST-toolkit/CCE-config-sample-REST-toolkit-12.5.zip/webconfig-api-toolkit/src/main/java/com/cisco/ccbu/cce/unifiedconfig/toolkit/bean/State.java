// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum State {
  DONE,
  IN_PROGRESS,
  ERROR,
  CANCELLED
}
