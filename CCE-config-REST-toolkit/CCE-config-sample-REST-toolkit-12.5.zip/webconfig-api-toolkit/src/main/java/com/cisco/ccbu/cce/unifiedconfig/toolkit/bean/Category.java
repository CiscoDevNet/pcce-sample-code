// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

public enum Category {
  STATUS,
  SYSTEM_VALIDATION,
  MACHINE_STATUS,
  OUT_OF_SYNC_DEVICES
}
