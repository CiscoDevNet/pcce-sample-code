// ----------------------------------------------
package com.cisco.ccbu.cce.unifiedconfig.toolkit.bean;

import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiBean;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.ws.rs.Path;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.ReferenceBean;
import java.util.Date;
import com.cisco.ccbu.cce.unifiedconfig.toolkit.BaseApiListBean;

import javax.xml.bind.annotation.XmlElement;

import javax.xml.bind.annotation.XmlElementWrapper;


@XmlRootElement(name="##default")
public class User extends BaseApiBean {
  private List<AssociatedGroup> associatedGroups;
  private List<String> cuicRoles;
  private String defaultUserGroup;
  private String description;
  private String firstName;
  private String id;
  private String lastName;
  private String permission;
  private Integer personId;
  private Agent sSOStateFromAgent;
  private boolean ssoEnabled;
  private String userName;
  private Integer version;

  public List<AssociatedGroup> getAssociatedGroups() {
     return this.associatedGroups;
  }

  public void setAssociatedGroups(List<AssociatedGroup> associatedGroups) {
     this.associatedGroups = associatedGroups;
  }

  public List<String> getCuicRoles() {
     return this.cuicRoles;
  }

  public void setCuicRoles(List<String> cuicRoles) {
     this.cuicRoles = cuicRoles;
  }

  public String getDefaultUserGroup() {
     return this.defaultUserGroup;
  }

  public void setDefaultUserGroup(String defaultUserGroup) {
     this.defaultUserGroup = defaultUserGroup;
  }

  public String getDescription() {
     return this.description;
  }

  public void setDescription(String description) {
     this.description = description;
  }

  public String getFirstName() {
     return this.firstName;
  }

  public void setFirstName(String firstName) {
     this.firstName = firstName;
  }

  public String getId() {
     return this.id;
  }

  public void setId(String id) {
     this.id = id;
  }

  public String getLastName() {
     return this.lastName;
  }

  public void setLastName(String lastName) {
     this.lastName = lastName;
  }

  public String getPermission() {
     return this.permission;
  }

  public void setPermission(String permission) {
     this.permission = permission;
  }

  public Integer getPersonId() {
     return this.personId;
  }

  public void setPersonId(Integer personId) {
     this.personId = personId;
  }

  public Agent getSSOStateFromAgent() {
     return this.sSOStateFromAgent;
  }

  public void setSSOStateFromAgent(Agent sSOStateFromAgent) {
     this.sSOStateFromAgent = sSOStateFromAgent;
  }

  public boolean getSsoEnabled() {
     return this.ssoEnabled;
  }

  public void setSsoEnabled(boolean ssoEnabled) {
     this.ssoEnabled = ssoEnabled;
  }

  public String getUserName() {
     return this.userName;
  }

  public void setUserName(String userName) {
     this.userName = userName;
  }

  public Integer getVersion() {
     return this.version;
  }

  public void setVersion(Integer version) {
     this.version = version;
  }


}
